import SwiftUI

struct AppColors {
    static let accent1 = Color(hex: "F3127F")
    static let accent2 = Color(hex: "BF1366")
    static let accent3 = Color(hex: "780C40")
}
